<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;


class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = Category::all();
        return["categories"=>$categories];
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data=$request->validate([
            "name" => "required|string|max:200",
            "description" => "required|string"
        ]);
        Category::create($data);
        return["data"=>$data];

    }

    /**
     * Display the specified resource.
     */
    public function show(Category $category)
    {
        return["category"=>$category];
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Category $category)
    {
        $data=$request->validate([
            "name" => "required|string|max:200",
            "description" => "required|string",
             ]);
        $category->update($data);  
        return [
            "massage" => "category is category",
            "category" => $data
        ];
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        $category->delete();
        return ["message"=> "category is deleted"];
    }
}
