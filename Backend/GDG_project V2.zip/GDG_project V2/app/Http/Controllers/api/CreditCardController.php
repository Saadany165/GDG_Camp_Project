<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Credit_card;
use Illuminate\Http\Request;
use Auth;

class CreditCardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $user = Auth::user();
        $data=$request->validate([
            "user_id" => "numeric",
            "cardholder_name" => "required|string",
            "card_number" => "required|numeric|digits:16",
            "expiry_date"=>"required|string|max:5",
            "card_type"=>"required|string",
            "cvv"=>"required|numeric|digits:3"
    
        ]);
        
        $data["user_id"]= $user->id;
        // if($data["user_id"]===$user->id){
        if($data["user_id"]){
            $card=Credit_card::create($data);
            return response()->json(["message"=>"card added"],200);
        }else{ return response()->json(["message"=>"can't add by this user"],500);}
    }

    /**
     * Display the specified resource.
     */
    public function show(Credit_card $credit_card)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,  $id)
    {
       //
    }

    public function remove_from_card($id)
    {
        $user= Auth::user();
        $card=Credit_card::findOrFail($id);
        if($user->id===$card->user_id){

            $card->delete();
            return response()->json(["message"=>"card deleted"],200);
        }else{return response()->json(["message"=>"can't delete this card"],500);}


    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy()
    {
        $user= Auth::user();
        $cards= Credit_card::where("user_id", $user->id)->get();
        // return response()->json($carts,200);
        if(count($cards)<1){
            return response()->json(["message"=>"not found card"],500);
        }else{
            foreach($cards as $card):
                $card->delete();
            endforeach;
        return response()->json(["message"=>"cards deleted"],200);
         }
    }
}
