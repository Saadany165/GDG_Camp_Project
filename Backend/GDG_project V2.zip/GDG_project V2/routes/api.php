<?php

use App\Http\Controllers\api\AuthController;
use App\Http\Controllers\api\CategoryController;
use App\Http\Controllers\api\ProductController;
use App\Http\Controllers\api\CreditCardController;
use App\Http\Controllers\api\UserController;
use App\Http\Controllers\api\CartController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

Route::apiResource("categories",CategoryController::class);
Route::apiResource("products",ProductController::class);

Route::post("register",[AuthController::class,"register"]);
Route::post("login",[AuthController::class,"login"]);
Route::post("logout",[AuthController::class,"logout"])->middleware("auth:sanctum");

Route::post("cart/add",[CartController::class,"add"])->middleware("auth:sanctum");
Route::get("cart",[CartController::class,"index"])->middleware("auth:sanctum");
Route::put("cart/update/{id}",[CartController::class,"update"])->middleware("auth:sanctum");
Route::delete("cart/remove/{id}",[CartController::class,"remove_from_cart"])->middleware("auth:sanctum");
Route::delete("cart/clear",[CartController::class,"clear"])->middleware("auth:sanctum");
Route::post("cart/checkout",[CartController::class,"checkout"])->middleware("auth:sanctum");
// Route::post("user/avatar",[AvatarController::class,"store"])->middleware("auth:sanctum");
Route::get("user/avatar",[UserController::class,"indexAvatar"])->middleware("auth:sanctum");
Route::post("user/avatar",[UserController::class,"updateAvatar"])->middleware("auth:sanctum");
Route::get("user/show",[UserController::class,"index"])->middleware("auth:sanctum");
Route::put("user/update",[UserController::class,"update"])->middleware("auth:sanctum");
Route::post("credit_card/add",[CreditCardController::class,"store"])->middleware("auth:sanctum");
Route::delete("credit_card/remove/{id}",[CreditcardController::class,"remove_from_card"])->middleware("auth:sanctum");
Route::delete("credit_card/clear",[CreditcardController::class,"destroy"])->middleware("auth:sanctum");




